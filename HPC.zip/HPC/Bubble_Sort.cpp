#include <bits/stdc++.h>
#include <omp.h>
#include <stdlib.h>
#include <array>
#include <chrono>
#include <functional>
#include <iostream>

using namespace std;

void s_bubble(vector<int> &arr)
{
    int n = arr.size();
    for (int i = 0; i < n; i++) {
        int first = i % 2;
        for (int j = first; j < n - 1; j += 2) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}

void p_bubble(vector<int> &arr)
{
    int n = arr.size();
    for (int i = 0; i < n; i++) {
        int first = i % 2;
#pragma omp parallel for shared(arr, first) num_threads(16)
        for (int j = first; j < n - 1; j += 2) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
            }
        }
    }
}


int main()
{
    const int size = 100000;
    vector<int> arr(size), arr_copy(size);

    for(int i=0; i<size; i++)
    {
        arr[i] = rand() % 1000;
        arr_copy[i] = arr[i];
    }


    // SEQUENTIAL BUBBLE SORT

    double start = omp_get_wtime();
    s_bubble(arr_copy);
    double end = omp_get_wtime();

    // cout<<"Sorted Using Sequential Bubble Sort Array: ";
    // for(int i=0; i<size; i++)
    // {
    //     cout<<arr_copy[i]<<" ";
    // }
    // cout<<endl;

    cout<<"Sequential Bubble Sort Time: " << (end - start) * 1000 << "ms" << endl;

    // PARALLEL BUBBLE SORT

    start = omp_get_wtime();
    p_bubble(arr);
    end = omp_get_wtime();

    // cout<<"Sorted Using Parallel Bubble Sort Array: ";
    // for(int i=0; i<size; i++)
    // {
    //     cout<<arr[i]<<" ";
    // }
    // cout<<endl;

    cout<<"Parallel  Bubble Sort Time: " << (end - start) * 1000 << "ms" << endl;


}