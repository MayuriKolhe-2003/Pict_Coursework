#include <bits/stdc++.h>
#include <omp.h>
#include <chrono>

using namespace std;

void merge(vector<int>&arr, int start, int end, int mid)
{
    vector<int>l;
    vector<int>r;

    for(int i=start; i<=mid;i++)
    {
        l.push_back(arr[i]);
    }
    for(int i = mid+1; i<=end; i++)
    {
        r.push_back(arr[i]);
    }

    int i=0,j=0,k=start;

    while (i<l.size() && j<r.size())
    {
        if(l[i] <= r[j])
        {
            arr[k] = l[i];
            i++;
        }
        else
        {
            arr[k] = r[j];
            j++;
        }
        k++;
    }

    while(i < l.size())
    {
        arr[k] = l[i];
        i++;
        k++;
    }
    while(j < r.size())
    {
        arr[k] = r[j];
        j++;
        k++;
    }
    
}

void s_mergesort(vector<int>&arr, int start, int end)
{
    if(end > start)
    {
        int mid = (start + end) / 2;
        s_mergesort(arr, start, mid);
        s_mergesort(arr, mid+1, end);
        merge(arr, start, end, mid);
    }

    // for(auto it:arr)
    // {
    //     cout<<it<<" ";
    // }
    // cout<<endl;
}

void p_mergesort(vector<int>&arr, int start, int end)
{
    if(end > start)
    {
        int mid = (start + end) / 2;
        #pragma omp parallel sections
        {
            #pragma omp section
            p_mergesort(arr, start, mid);

            #pragma omp section
            p_mergesort(arr, mid+1, end);
        }
        merge(arr, start, end, mid);
    }
    // for(auto it:arr)
    // {
    //     cout<<it<<" ";
    // }
    // cout<<endl;
}

int main()
{
    int size = 100000000;
    vector<int> v(size), vcopy(size);
    for(int i=0;i<size;i++)
    {
        v[i] = rand() % 100;
        vcopy[i] = v[i];
    }

    double start = omp_get_wtime();
    s_mergesort(v, 0, size-1);
    double end = omp_get_wtime();
    cout << "Sequential Merge Sort Time: " << end - start << " seconds" << endl;


    start = omp_get_wtime();
    p_mergesort(v, 0, size-1);
    end = omp_get_wtime();
    cout << "Parallel Merge Sort Time: " << end - start << " seconds" << endl;


    return 0;
}