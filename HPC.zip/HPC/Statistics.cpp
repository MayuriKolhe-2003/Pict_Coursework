#include <bits/stdc++.h>
#include <omp.h>
#include <stdlib.h>
#include <chrono>
#include <limits.h>
#include <iostream>

using namespace std;
using std::chrono::duration_cast;
using std::chrono::high_resolution_clock;
using std::chrono::milliseconds;


void s_avg(vector<int> &arr, int n)
{
  long sum = 0 ;
  for(int i=0; i<n; i++)
  {
    sum += arr[i];
  }
  cout<< sum / long(n);
}

void p_avg(vector<int> &arr, int n)
{
    long sum = 0L;
    int i;
    #pragma omp parallel for reduction(+ : sum) num_threads(16)
    for(i=0; i<n; i++)
    {
        sum = sum + arr[i];
    }
    cout<< sum / long(n);
}

void s_sum(vector<int> &arr, int n)
{
  long sum = 0 ;
  for(int i=0; i<n; i++)
  {
    sum += arr[i];
  }
  cout<< sum ;
}

void p_sum(vector<int> &arr, int n)
{
    long sum = 0L;
    int i;
    #pragma omp parallel for reduction(+ : sum) num_threads(16)
    for(i=0; i<n; i++)
    {
        sum = sum + arr[i];
    }
    cout<< sum ;
}

void s_max(vector<int> &arr, int n)
{
    int max_val = INT_MIN;
    for(int i=0;i<n;i++)
    {
        if(arr[i] > max_val)
        {
            max_val = arr[i];
        }
    }
    cout<< max_val ;
}

void p_max(vector<int> &arr, int n)
{
    int max_val = INT_MIN;
    int i;
    #pragma omp parallel for reduction(max : max_val) num_threads(16)
    for(i=0;i<n;i++)
    {
        if(arr[i] > max_val)
        {
            max_val = arr[i];
        }
    }
    cout<< max_val ;
}

void s_min(vector<int> &arr, int n)
{
    int min_val = INT_MAX;
    for(int i=0;i<n;i++)
    {
        if(arr[i] < min_val)
        {
            min_val = arr[i];
        }
    }
    cout<< min_val ;
}

void p_min(vector<int> &arr, int n)
{
    int min_val = INT_MAX;
    int i;
    #pragma omp parallel for reduction(min : min_val) num_threads(16)
    for(i=0;i<n;i++)
    {
        if(arr[i] < min_val)
        {
            min_val = arr[i];
        }
    }
    cout<< min_val ;
}

std::string bench_traverse(std::function<void()> traverse_fn)
{
    auto start = high_resolution_clock::now();
    traverse_fn();
    cout<< "(";
    auto stop = high_resolution_clock::now();
    auto duration = duration_cast<milliseconds>(stop-start);
    return std::to_string(duration.count());
}

int main()
{
    int size = 1000000000;
    vector<int>arr(size);
    for(int i=0; i<size; i++)
    {
        arr[i] = rand() % 100;
    }

    omp_set_num_threads(16);

   cout<<"Sequential Min : " << bench_traverse([&] { s_min(arr, size);}) << "ms)"<<endl;
   cout<<"Parallel Min : " << bench_traverse([&] { p_min(arr, size);}) << "ms)"<<endl;

   cout<<"Sequential max : " << bench_traverse([&] { s_max(arr, size);}) << "ms)"<<endl;
   cout<<"Parallel max : " << bench_traverse([&] { p_max(arr, size);}) << "ms)"<<endl;


   cout<<"Sequential sum : " << bench_traverse([&] { s_sum(arr, size);}) << "ms)"<<endl;
   cout<<"Parallel sum : " << bench_traverse([&] { p_sum(arr, size);}) << "ms)"<<endl;

   cout<<"Sequential AVg : " << bench_traverse([&] { s_avg(arr, size);}) << "ms)"<<endl;
   cout<<"Parallel AVg : " << bench_traverse([&] { p_avg(arr, size);}) << "ms)"<<endl;

}